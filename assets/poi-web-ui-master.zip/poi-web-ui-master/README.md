# poi-web-ui
Person of Interest (Machine &amp; Samaritan) styled collection of components for web pages.

This is a web components collection like Bootstrap components (cards, panels, etc) styled the popular series Person of Interest.<br />
You can use with all grid-systems/css frameworks.<br />
This demo contains: Bootstrap 4 and W3.css 4.

Content: blocks, cards, boxes, buttons, form elements.<br />
Extra content in the samples section 1-1 demo component (carousel, lightbox) from bs and w3 for sample videos, images from witch i created.


## Web

<a href="https://phresh-it.hu/" target="_blank">Phresh-IT</a>

<a href="https://phresh-it.hu/demos/poi-web-ui/" target="_blank">poi-web-ui demo</a>


## Licence
Copyright (c) 2018, Krisztián Kis - Phresh-IT. All rights reserved.

### Support

If you like my work(s), please buy me a coffee or support/donate me. Contributions, issues(problems, ideas) and [donates](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=L3HSBGM4JTKEL&source=url) are welcome.

Thank you, Have a nice day!
